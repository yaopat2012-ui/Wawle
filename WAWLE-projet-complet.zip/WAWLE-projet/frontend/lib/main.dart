import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Pass the deployed HTTPS API URL at build time:
// flutter build apk --release --dart-define=API_BASE_URL=https://your-api.example.com
const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

void main() => runApp(const WawleApp());

class WawleApp extends StatelessWidget {
  const WawleApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'WAWLE',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B57)), useMaterial3: true),
        home: const ChatPage(),
      );
}

class ChatMessage {
  final String role;
  final String content;
  ChatMessage(this.role, this.content);
  Map<String, String> toJson() => {'role': role, 'content': content};
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final scrollController = ScrollController();
  final messages = <ChatMessage>[];
  bool busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('history');
    if (raw == null || !mounted) return;
    try {
      final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
      setState(() => messages.addAll(list.map((m) => ChatMessage(m['role'] as String, m['content'] as String))));
    } catch (_) {}
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('history', jsonEncode(messages.map((m) => m.toJson()).toList()));
  }

  Future<void> send() async {
    final text = controller.text.trim();
    if (text.isEmpty || busy) return;
    if (apiBaseUrl.isEmpty) {
      setState(() => error = 'Configuration requise : l’adresse HTTPS de l’API WAWLE doit être ajoutée lors de la compilation.');
      return;
    }
    controller.clear();
    setState(() { messages.add(ChatMessage('user', text)); busy = true; error = null; });
    await _saveHistory();
    try {
      final response = await http.post(Uri.parse('$apiBaseUrl/chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'messages': messages.map((m) => m.toJson()).toList()}),
      ).timeout(const Duration(seconds: 70));
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception(data['detail'] ?? 'Erreur du serveur (${response.statusCode}).');
      }
      setState(() => messages.add(ChatMessage('assistant', data['reply'] as String? ?? 'Aucune réponse reçue.')));
      await _saveHistory();
    } catch (e) {
      setState(() => error = 'Impossible de contacter WAWLE. Vérifie la connexion et l’adresse de l’API.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> clearHistory() async {
    setState(() { messages.clear(); error = null; });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('history');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Row(children: [Icon(Icons.auto_awesome), SizedBox(width: 10), Text('WAWLE')]), actions: [IconButton(tooltip: 'Effacer la conversation', onPressed: clearHistory, icon: const Icon(Icons.delete_outline))]),
    body: SafeArea(child: Column(children: [
      Expanded(child: messages.isEmpty ? const Center(child: Padding(padding: EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.forum_outlined, size: 54), SizedBox(height: 14), Text('Bonjour ! Je suis WAWLE.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Pose-moi une question pour commencer.', textAlign: TextAlign.center)]))) : ListView.builder(controller: scrollController, padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (context, i) {
        final m = messages[i]; final user = m.role == 'user';
        return Align(alignment: user ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.all(12), constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .88), decoration: BoxDecoration(color: user ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)), child: user ? Text(m.content) : MarkdownBody(data: m.content, selectable: true)));
      })),
      if (busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
      if (error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10), child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Expanded(child: TextField(controller: controller, minLines: 1, maxLines: 5, textInputAction: TextInputAction.newline, decoration: const InputDecoration(hintText: 'Écris ton message…', border: OutlineInputBorder(), isDense: true))), const SizedBox(width: 8), IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send), tooltip: 'Envoyer')]))
    ])),
  );

  @override
  void dispose() { controller.dispose(); scrollController.dispose(); super.dispose(); }
}
