# WAWLE

Assistant intelligent Android avec interface Flutter et API FastAPI.

## Structure
- `frontend/` : application Flutter Android
- `backend/` : API FastAPI qui appelle un fournisseur IA compatible OpenAI
- `.github/workflows/build-apk.yml` : compilation APK via GitHub Actions

## Backend
Définir `AI_API_KEY` (clé privée du fournisseur IA) et facultativement `AI_BASE_URL` et `AI_MODEL`.
Installer `backend/requirements.txt`, puis lancer :

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Ne jamais mettre la clé API dans l'application Flutter ou dans GitHub public.

## Application
Dans `frontend/`, définir `API_BASE_URL` avec l'adresse HTTPS publique du backend, puis lancer `flutter pub get` et `flutter build apk --release`.

## GitHub Actions
Après avoir importé le contenu du projet dans la racine du dépôt, ouvrir l'onglet Actions et lancer « Build WAWLE APK ». L'APK sera disponible dans les artefacts du workflow si la compilation réussit.
