import os
from typing import List, Literal
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="WAWLE API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)

class ChatRequest(BaseModel):
    messages: List[Message] = Field(min_length=1, max_length=40)

@app.get("/")
def root():
    return {"app": "WAWLE", "status": "ok"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/chat")
async def chat(body: ChatRequest):
    api_key = os.getenv("AI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Le service IA n'est pas encore configuré côté serveur.")
    base_url = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.getenv("AI_MODEL", "gpt-4o-mini")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "Tu es WAWLE, un assistant intelligent utile, clair et respectueux. Réponds dans la langue de l'utilisateur."},
            *[m.model_dump() for m in body.messages],
        ],
    }
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json=payload,
            )
        response.raise_for_status()
        data = response.json()
        answer = data["choices"][0]["message"]["content"]
        return {"reply": answer}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail="Le fournisseur IA a refusé la requête. Vérifie la configuration du serveur.") from exc
    except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
        raise HTTPException(status_code=502, detail="Le service IA est temporairement indisponible.") from exc
